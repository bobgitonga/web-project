<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['adminname'])) {
    header("Location: index.html");
}else{
  $filter = $_SESSION['adminname'];
  $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `User_ID`='$filter'")or die(mysqli_error());
  $row1=mysqli_fetch_array($query);
}
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>
    TextiCycle - Administrator Homepage
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

        <style type="text/css">
        
          table{
    align-items: center;
  }

   th, tr, td{
    padding: 10px 10px;
  }
    </style>

            <script type="text/javascript">
function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
})  
</script>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <nav class="navbar navbar-expand-lg custom_nav-container ">
        <a class="navbar-brand" href="index.php">
          <span>
            TextiCycle
          </span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class=""></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav  ">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#data">
                View Data
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#module">
                My Module
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">
                Contact Us
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact Us</a>
            </li>
          </ul>
          <div class="user_option">
            <a href="logout.php">
              <i class="fa fa-user" aria-hidden="true"></i>
              <span>
                Logout
              </span>
            </a>
          </div>
        </div>
      </nav>
    </header>
    <!-- end header section -->
    <!-- slider section -->

    <section class="slider_section">
      <div class="slider_container">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-7">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,<br>
                        <?php echo $row1['Fullname']; ?>! 
                      </h1>
                      <p>
                        Donate Textiles, Save the Environment.
                      </p>
                      <a href="#contact">
                        Contact Us
                      </a>
                    </div>
                  </div>
                  <div class="col-md-5 ">
                    <div class="img-box">
                      <img src="images/h1.jpg" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item ">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-7">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,<br>
                        <?php echo $row1['Fullname']; ?>! 
                      </h1>
                      <p>
                        Transforming Old Fabrics into New Opportunities.
                      </p>
                      <a href="#module">
                        My Module
                      </a>
                    </div>
                  </div>
                  <div class="col-md-5 ">
                    <div class="img-box">
                      <img src="images/h2.jpg" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item ">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-7">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,<br>
                        <?php echo $row1['Fullname']; ?>! 
                      </h1>
                      <p>
                        Supporting Eco-Friendly Practices, One Donation at a Time.
                      </p>
                      <a href="#data">
                        View Data
                      </a>
                    </div>
                  </div>
                  <div class="col-md-5 ">
                    <div class="img-box">
                      <img src="images/h3.jpg" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel_btn-box">
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <i class="fa fa-arrow-left" aria-hidden="true"></i>
              <span class="sr-only">Previous</span>
            </a>
            <img src="images/line.png" alt="" />
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <i class="fa fa-arrow-right" aria-hidden="true"></i>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
      </div>
    </section>
    <br>
    <br>

    <!-- end slider section -->
  </div>
  <!-- end hero area -->

  <!-- view data section -->

  <section id="data" class="why_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          View Data
        </h2>
      </div>
      <div class="row">
        <div class="col-md-12">
                      <div class="detail-box">
              <h5>
                List of Users
              </h5>
              <br>
            </div>
        <table id="printTable">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">User ID</th>
<th style="text-align: left;
  padding: 8px;">Fullname</th>
  <th style="text-align: left;
  padding: 8px;">Email Address</th>
 <th style="text-align: left;
  padding: 8px;">Phone Number</th>
  <th style="text-align: left;
  padding: 8px;">User Type</th>
   <th style="text-align: left; padding: 8px;"></th>
</tr>

<?php
$sql = "SELECT `User_ID`, `Fullname`, `Recycling_Center`, `Phone_Number`, `Email_Address`, `User_Type` FROM `users`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["User_ID"]); ?></td>
<?php
if($row["Recycling_Center"] != ""){
?>
<td><?php echo($row["Fullname"]); ?> from <?php echo($row["Recycling_Center"]); ?></td>
<?php
}else{
?>
<td><?php echo($row["Fullname"]); ?></td>
<?php
}
?>
<td><?php echo($row["Email_Address"]); ?></td>
<td><?php echo($row["Phone_Number"]); ?></td>
<td><?php echo($row["User_Type"]); ?></td>
<td><button class="btn btn-primary py-3 px-5" onclick="return confirm('Are you sure that you want to delete this user?')?window.location.href='insertion.inc.php?action=deleteU&id=<?php echo($row["User_ID"]); ?>':true;" title='Delete User'>Delete</button></td>
</tr>
<?php
}
} else { echo "No results"; }

?>

</table>
<br>
<br>
              <div class="btn-box">
                <a onclick="printData();" class="btn1">
                  Generate Report
                </a>
              </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end view data section -->

  <!-- module section -->

  <section id="module" class="contact_section ">
    <div class="container px-0">
      <div class="heading_container ">
        <h2 class="">
          My Module
        </h2>
      </div>
    </div>
    <div class="container container-bg">
      <div class="row">
        <div class="col-lg-7 col-md-6 px-0">
          <form action="insertion.inc.php" method="POST">
            <div>
              <input type="text" required name="fname" placeholder="Fullname" value="<?php echo $row1['Fullname'] ?>" />
              <input type="hidden" value="1" name="mod" required>
              <input type="hidden" value="<?php echo $filter; ?>" name="uid" required>
            </div>
            <div>
              <input type="email" required name="email" placeholder="Email Address" value="<?php echo $row1['Email_Address'] ?>" />
            </div>
            <div>
              <input type="text" required name="phone" placeholder="Phone Number" value="<?php echo $row1['Phone_Number'] ?>" />
            </div>
            <div>
              <input type="password" required name="password" placeholder="Password" />
            </div>
            <div>
              <input type="password" required name="cpassword" placeholder="Confirm Password" />
            </div>                        
            <div class="d-flex ">
              <button type="submit" name="upu">
                UPDATE MY DETAILS
              </button>
            </div>
          </form>
        </div>
        <div class="col-md-6 col-lg-5 px-0">
          <form action="insertion.inc.php" method="POST">
            <div>
              <input type="text" required name="fname" placeholder="Fullname" />
            </div>
            <div>
              <input type="text" name="rec" placeholder="Recycling Center (if User is a Recycling Center Member else leave empty)" />
            </div>
            <div>
              <input type="email" required name="email" placeholder="Email Address" />
            </div>
            <div>
              <input type="text" required name="phone" placeholder="Phone Number" />
            </div>
            <div>
              <select name="type" required>
                <option selected disabled value="">Select A User Type</option>
                <option value="Administrator">Administrator</option>
                <option value="Recycling Center Member">Recycling Center Member</option>
                <option value="User">User</option>
              </select>
            </div>
            <div>
              <input type="password" required name="password" placeholder="Password" />
            </div>
            <div>
              <input type="password" required name="cpassword" placeholder="Confirm Password" />
            </div>                        
<!--             <div>
              <input type="text" required name="" class="message-box" placeholder="Message" />
            </div> -->
            <div class="d-flex ">
              <button type="submit" name="regu">
                REGISTER
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end my module section -->

  <!-- contact us section -->

  <section class="info_section  layout_padding2-top">
    <div class="social_container">
      <div class="social_box">
        <a href="">
          <i class="fa fa-facebook" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-twitter" aria-hidden="true"></i>
        </a>
        <a href="">
          <i class="fa fa-instagram" aria-hidden="true"></i>
        </a>
      </div>
    </div>
    <div class="info_container ">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-12">
            <h6>
              CONTACT US
            </h6>
            <div class="info_link-box">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span> Nairobi, Kenya. </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>+254 112160569</span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span> texticyle@gmail.com</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- footer section -->
    <footer class=" footer_section">
      <div class="container">
        <p>
          &copy; <span id="displayYear"></span> All Rights Reserved By
        </p>
      </div>
    </footer>
    <!-- footer section -->

  </section>

  <!-- end contact us section -->


  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <script src="js/custom.js"></script>

</body>

</html>