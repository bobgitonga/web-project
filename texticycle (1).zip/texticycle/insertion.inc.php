<?php 
 
require 'connect.php';

session_start();

//Register User
if (isset($_POST['regu'])) {
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $type = $_POST['type'];
 $mod = $_POST['mod'];
 $rec = $_POST['rec'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

 if ($password == $passwordconfirm) {
    if($mod == 1){
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`,`User_Type`, `Password`) VALUES ('$fname','$phone','$email','User',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.html?userregistration=success");
 }else{
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Recycling_Center`, `Email_Address`, `User_Type`, `Password`) VALUES ('$fname','$phone','$rec','$email','$type',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.php?userregistration=success");
  }
}else{
  echo "Passwords do not match.";
 }
}

//Update User
if (isset($_POST['upu'])) {
 $uid = $_POST['uid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];

 if ($password == $passwordconfirm) {
  if ($mod == 1) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index.php?updateadministrator=success");
  }else if ($mod == 2) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index1.php?updaterecyclecenterstaff=success");
  }else if ($mod == 3) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: index2.php?updateuser=success");
  }
 }else{
  echo "Passwords do not match.";
 }
}

//Delete A User
if($_REQUEST['action'] == 'deleteU' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `users` WHERE `User_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
header("Location: index.php?deleteuser=success");
}

//Add a Donation
if (isset($_POST['adddonation'])) {
 $uid = $_SESSION['username'];
 $rid = $_POST['rid'];
 $ddet = $_POST['ddet'];
 $dtype = $_POST['dtype'];  
 $quan = $_POST['quan'];

$imagefile = $_FILES['image']['name'];

$valid_extensions = array("jpg","jpeg","png");

$extension = pathinfo($imagefile, PATHINFO_EXTENSION);

if(in_array(strtolower($extension),$valid_extensions) ) {

if(move_uploaded_file($_FILES['image']['tmp_name'], "images/".$imagefile)){

  $sql = "INSERT INTO `donations`(`User_ID`, `Recycling_Center_ID`, `Type`, `Details`, `Quantity`, `Image`) VALUES ('$uid','$rid','$dtype','$ddet','$quan','$imagefile')";
     mysqli_query($conn, $sql);
  header("Location: index2.php?adddonation=success");
 }else{
  echo "There is an error with storing the image, directory not found.";
}
}else{
  echo "There is an error with the storing image, kindly check the image format.";
}
}

//Accept a Donation
if($_REQUEST['action'] == 'acceptD' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `donations` SET `Status` = 'Accepted', `Updated_At` = NOW() WHERE `Donation_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: index1.php?acceptDonation=success");
}

//Complete a Donation
if($_REQUEST['action'] == 'completeD' && !empty($_REQUEST['id']) && !empty($_REQUEST['id1'])){ 
$updateItem = $_REQUEST['id'];
$deal = $_REQUEST['id1'];
if($deal == 'Commercial'){
$sql = "UPDATE `donations` SET `Status` = 'Completed & Donations Sold.', `Updated_At` = NOW() WHERE `Donation_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
}else{
$sql = "UPDATE `donations` SET `Status` = 'Completed & Donations Recycled.', `Updated_At` = NOW() WHERE `Donation_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
}
header("Location: index1.php?completeDonation=success");
}

//Cancel a Donation
if($_REQUEST['action'] == 'cancelD' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `donations` SET `Status` = 'Cancelled', `Updated_At` = NOW() WHERE `Donation_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: index2.php?cancelDonation=success");
}

 ?>